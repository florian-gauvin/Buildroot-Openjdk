#!/bin/sh 
echo >&2 "No suitable 'install' command found.'" 
echo >&2 "If automake is installed, running 'automake -fa'" 
echo >&2 "(and ignoring the errors) might produce one." 
exit 1 
